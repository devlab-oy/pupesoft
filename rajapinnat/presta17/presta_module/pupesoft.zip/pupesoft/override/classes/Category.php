<?php

class Category extends CategoryCore {

    public $pupesoft_id;

    public function __construct($id_category = null, $id_lang = null, $id_shop = null){
        self::$definition['fields']['pupesoft_id'] = array('type' => self::TYPE_HTML, 'lang' => true);
        parent::__construct($id_category, $id_lang, $id_shop);
    }

}