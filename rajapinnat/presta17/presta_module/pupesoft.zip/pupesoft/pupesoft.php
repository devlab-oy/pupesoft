<?php

if (!defined('_PS_VERSION_'))
    exit;

class Pupesoft extends Module
{
    public function __construct()
    {
        $this->name = 'pupesoft';
        $this->tab = 'front_office_features';
        $this->version = '1.0';
        $this->author = 'Igor Olhovski';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = array('min' => '1.7.1', 'max' => _PS_VERSION_);
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Pupesoft');
        $this->description = $this->l('Adds pupesoft id to pupesoft');
    }

    public function install()
    {
        if (!parent::install() || !$this->_installSql()) {
            return false;
        }

        return true;
    }

    public function uninstall()
    {
        return parent::uninstall() && $this->_unInstallSql();
    }

    protected function _installSql() {
        $sqlInstall = "ALTER TABLE " . _DB_PREFIX_ . "category_lang "
            . "ADD COLUMN pupesoft_id LONGTEXT NULL";

        $returnSql = Db::getInstance()->execute($sqlInstall);

        return $returnSql;
    }

    protected function _unInstallSql() {
        $sqlInstall = "ALTER TABLE " . _DB_PREFIX_ . "category_lang "
            . "DROP pupesoft_id";

        $returnSql = Db::getInstance()->execute($sqlInstall);

        return $returnSql;
    }
}